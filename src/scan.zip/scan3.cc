/******************************************************/
/* scan3.cc: scan two integers separated by characters
/* Input: 444===++//555
/* Output: "The numbers were 444 and 555."
/* Author: Marcus Birkenkrahe (pledged)
/* Date: 02/14/2025
/*****************************************************/
#include <stdio.h>
int main()
{
  // variable declarations
  int i,j;

  // read keyboard input
  scanf("%d==++//%d",&i,&j);

  // print keyboard input
  printf("The numbers were %d and %d.\n",i,j);

  return 0;
}

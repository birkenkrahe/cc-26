/******************************************************/
/* scan2.cc: scan integer separated by /
/* Input: 5/ 96  and 5 / 96 and .5 / 96
/* Output: correct and incorrect output
/* Author: Marcus Birkenkrahe (pledged)
/* Date: 02/14/2025
/*****************************************************/
#include <stdio.h>
int main()
{
  // variable declarations
  int i,j;

  // ask for keyboard input
  puts("Enter two integers separated by `/`:");

  // read keyboard input
  scanf("%d/%d",&i,&j);

  // print keyboard input
  printf("|%5d|%5d|\n",i,j);

  return 0;
}

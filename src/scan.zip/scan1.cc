/******************************************************/
/* scan1.cc: scan integer and floating point variables
/* Input: 100 -1000 .456 -9.34e2
/* Output:  |  100|-1000|0.456| -934|
/* Author: Marcus Birkenkrahe (pledged)
/* Date: 02/14/2025
/*****************************************************/
#include <stdio.h>
int main()
{
  // variable declarations
  int k, l;
  float u, v;

  // ask user for keyboard input
  puts("Enter two int and two float values");

  // get keyboard input
  scanf("%d%d%f%e",&k,&l,&u,&v);

  // print keyboard input
  printf("|%d|%d|%.3f|%.0f|\n",k,l,u,v);
  return 0;
}
